# JavaAndSeleniumConcepts
Repository for different Java and Selenium Topics/Concepts

This repository demonstrates different Java programming examples and web testing related scenarios solved using Selenium libraries.
