/** */
package com.qa.base;

/** @author deepak Rai */
public enum BrowserNames {
  CHROME,
  FF,
  IE,
  EDGE
}
