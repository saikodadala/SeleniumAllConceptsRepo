package javaPrograms.ReadWriteWithXML;

public class Person {

  String firstName;
  String lastName;
  int age;
  Address address;
  String[] cars;

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public String[] getCars() {
    return cars;
  }

  public void setCars(String[] cars) {
    this.cars = cars;
  }
} // End of class Person
