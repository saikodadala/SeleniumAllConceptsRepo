package javaPrograms.InheritanceExamples;

public class Parent {

  int a = 10;

  public void m1() {
    System.out.println("Parent");
  }
}
