package javaPrograms;

public record Range(int low, int high) {}
